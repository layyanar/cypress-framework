/// <reference types="Cypress" />
import { Given, Then, When } from "cypress-cucumber-preprocessor/steps";

const storePage = require("../pages/StorePage");
const cartPage = require("../pages/Cartpage");
const page = require("../pages/Page");

Given("User is on shopcart page", function () {
  cy.visit("http://localhost:3000/");
});

When(/^User add "([^"]*)" product to cart$/, function (product) {
  storePage.addProduct(product);
});

Then(/^User should see the "([^"]*)" product in cart$/, function (product) {
  cartPage.navigateToCart();
  cartPage.verifyProductInCart(product);
});

Then(/^User should see "([^"]*)" item in cart$/, function (noOfItems) {
  cartPage.verifyTotalItems(noOfItems);
});

Then(/^Total value of the cart should be "([^"]*)"$/, function (value) {
  cartPage.verifyTotalValueOfCart(value);
});

Then(/^User clicks on "([^"]*)" button$/, function (button) {
  cartPage.clickOnButtonWithText(button);
});

Then(/^User should see "([^"]*)" message$/, function (message) {
  cartPage.verifyCartIsEmpty(message);
});
Then(/^User increase quantity of "([^"]*)" by (-?\d+)$/, function (
  product,
  quantity
) {
  cartPage.increaseProductQuantity(product, quantity);
});
Then(/^User decrease quantity of "([^"]*)" by (-?\d+)$/, function (
  product,
  quantity
) {
  cartPage.decreaseProductQuantity(product, quantity);
});

Then(/^"([^"]*)" button should be displayed for "([^"]*)" product$/, function (
  buttonType,
  product
) {
  cartPage.verifyButtonsForProduct(buttonType, product);
});

Then(/^User deletes the "([^"]*)" product$/, function (product) {
  cartPage.deleteProduct(product);
});

Then(/^User should see "([^"]*)" message$/, function (message) {
  cartPage.verifyMessage(message);
});
