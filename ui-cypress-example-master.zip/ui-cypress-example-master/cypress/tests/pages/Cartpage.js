/// <reference types="Cypress" />
import Page from "./Page";

const cart = 'a[href="/cart"]';
class CartPage extends Page {
    get cart (){ return cy.xpath('//a[@href="/cart"]')}
    getItemsInCart() {return cy.xpath('//p[text()="Total Items"]/following-sibling::h4'); }
    getproductInCart(product) { return cy.xpath('//h5[text()="' + product + '"]');}
    get noOfItemsfromCart() { return cy.xpath('//p[text()="Total Items"]/following-sibling::h4');}
    get totalPayment() {return cy.xpath('//p[text()="Total Payment"]/following-sibling::h3');}
    get cartEmptyMessage(){return cy.xpath('//div[text()="Your cart is empty"]|//p[text()="Checkout successfull"]')}
    getIncreaseItemButton(product){return cy.xpath('//h5[text()="'+product+'"]/..//following-sibling::div/following-sibling::div/button[@class="btn btn-primary btn-sm mr-2 mb-1"]');}
    getreduceButton(product){return cy.xpath('//h5[text()="'+product+'"]/../following-sibling::div/following-sibling::div/button[@class="btn btn-danger btn-sm mb-1"]');}
    getdeleteButton(product){return cy.xpath('//h5[text()="'+product+'"]/../following-sibling::div/following-sibling::div/button[@class="btn btn-danger btn-sm mb-1"]');}
    getMessage(message){return cy.xpath('//p[text()="'+message+'"]');}

  navigateToCart() {
    this.cart.click()
  }

  verifyProductInCart(product) {
    cy.findByText(product);
  }

  verifyTotalItems(noOfItems) {
    this.getItemsInCart().should("contain.text", noOfItems);
  }

  verifyTotalValueOfCart(value) {

    this.totalPayment.should('contain.text',value);
   
  }
  verifyCartIsEmpty(message) {
    this.cartEmptyMessage.should('contain.text',message)
  }

  increaseProductQuantity(product, quantity) {
    for (var i = 0; i < quantity; i++) {
      this.getIncreaseItemButton(product).click();
    }
  }

  decreaseProductQuantity(product, quantity) {
    for (var i = 0; i < quantity; i++) {
      this.getreduceButton(product).click();
    }
  }

  verifyButtonsForProduct(button, product) {
    if (button == "Reduce") {
      this.getreduceButton(product).should('be.visible')
    } else this.getreduceButton(product).should('be.visible')
  }

  deleteProduct(product) {
    this.getdeleteButton(product).click();
  }

  verifyMessage(message) {
  this.getMessage(message).should('be.visible')
  }
}
module.exports = new CartPage();
