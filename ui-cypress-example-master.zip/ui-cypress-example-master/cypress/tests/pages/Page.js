/// <reference types="Cypress" />
export default class Page {
  clickOnButtonWithText(button) {
    var ele = cy.xpath('//button[text()="' + button + '"]');
    ele.click();
  }
}
