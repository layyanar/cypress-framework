/// <reference types="Cypress" />
import Page from "./page";
class StorePage extends Page {
  addProduct(product) {
    cy.xpath('//p[text()="' + product + '"]/parent::div//button').click();
  }
}
module.exports = new StorePage();
